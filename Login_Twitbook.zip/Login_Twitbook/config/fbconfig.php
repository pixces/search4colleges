<?php



define('APP_ID', 'Facebook APP ID');
define('APP_SECRET', 'Facebook Secret');


?>
